<?php
if (!defined('ABSPATH')) { exit; }

class WC_Gateway_GetaPay extends WC_Payment_Gateway {
    private $api;
    private $getapay_countries;

    public function __construct() {
        $this->id = 'getapay';
        $this->method_title = __('GetaPay', 'getapay-woocommerce');
        $this->method_description = __('Accept Mobile Money and bank card payments through GetaPay.', 'getapay-woocommerce');
        $this->has_fields = true;
        $this->supports = array('products');
        $this->getapay_countries = $this->country_map();
        $this->init_form_fields();
        $this->init_settings();
        $this->title = $this->get_option('title', 'GetaPay');
        $this->description = $this->get_option('description', __('Pay securely with Mobile Money or bank card.', 'getapay-woocommerce'));
        $this->enabled = $this->get_option('enabled', 'no');
        $this->api = new GetaPay_API($this->get_option('secret_key'));
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        add_action('woocommerce_receipt_' . $this->id, array($this, 'receipt_page'));
        add_action('woocommerce_api_getapay_webhook', array($this, 'handle_webhook'));
        add_action('rest_api_init', array($this, 'register_rest_routes'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_assets'));
        add_action('woocommerce_checkout_process', array($this, 'validate_checkout'));
        add_filter('woocommerce_available_payment_gateways', array($this, 'limit_available_gateway'));
    }

    private function country_map() {
        return array(
            'BEN'=>array('name'=>'Bénin','currency'=>'XOF','providers'=>array('MTN','MOOV')),
            'BFA'=>array('name'=>'Burkina Faso','currency'=>'XOF','providers'=>array('ORANGE','MOOV')),
            'CMR'=>array('name'=>'Cameroun','currency'=>'XAF','providers'=>array('MTN','ORANGE')),
            'CIV'=>array('name'=>"Côte d’Ivoire",'currency'=>'XOF','providers'=>array('ORANGE','MTN','MOOV','WAVE')),
            'COD'=>array('name'=>'RD Congo','currency'=>'CDF','providers'=>array('MPESA','AIRTEL','ORANGE','VODACOM')),
            'COG'=>array('name'=>'Congo','currency'=>'XAF','providers'=>array('AIRTEL','MTN')),
            'MLI'=>array('name'=>'Mali','currency'=>'XOF','providers'=>array('ORANGE','MOOV')),
            'SEN'=>array('name'=>'Sénégal','currency'=>'XOF','providers'=>array('ORANGE','FREE','EXPRESSO','WAVE','WIZALL')),
            'TGO'=>array('name'=>'Togo','currency'=>'XOF','providers'=>array('TMONEY','MOOV')),
            'GAB'=>array('name'=>'Gabon','currency'=>'XAF','providers'=>array('AIRTEL','MOOV')),
            'KEN'=>array('name'=>'Kenya','currency'=>'KES','providers'=>array('MPESA','AIRTEL')),
            'RWA'=>array('name'=>'Rwanda','currency'=>'RWF','providers'=>array('MTN','AIRTEL')),
            'SLE'=>array('name'=>'Sierra Leone','currency'=>'SLE','providers'=>array('ORANGE','AIRTEL')),
            'UGA'=>array('name'=>'Ouganda','currency'=>'UGX','providers'=>array('MTN','AIRTEL')),
            'ZMB'=>array('name'=>'Zambie','currency'=>'ZMW','providers'=>array('MTN','AIRTEL')),
        );
    }

    public function init_form_fields() {
        $this->form_fields = array(
            'enabled'=>array('title'=>__('Activer', 'getapay-woocommerce'),'type'=>'checkbox','label'=>__('Activer GetaPay', 'getapay-woocommerce'),'default'=>'no'),
            'title'=>array('title'=>__('Titre affiché', 'getapay-woocommerce'),'type'=>'text','default'=>'GetaPay'),
            'description'=>array('title'=>__('Description', 'getapay-woocommerce'),'type'=>'textarea','default'=>__('Payez par Mobile Money ou carte bancaire.', 'getapay-woocommerce')),
            'secret_key'=>array('title'=>__('Clé secrète API', 'getapay-woocommerce'),'type'=>'password','description'=>__('Clé gp_sk_live_ — conservée côté serveur.', 'getapay-woocommerce'),'default'=>''),
            'webhook_secret'=>array('title'=>__('Secret webhook', 'getapay-woocommerce'),'type'=>'password','description'=>__('Secret whsec_ fourni dans GetaPay → API & Webhooks.', 'getapay-woocommerce'),'default'=>''),
            'methods'=>array('title'=>__('Moyens de paiement autorisés', 'getapay-woocommerce'),'type'=>'select','default'=>'both','options'=>array('both'=>__('Mobile Money et carte', 'getapay-woocommerce'),'mobile'=>__('Mobile Money uniquement', 'getapay-woocommerce'),'card'=>__('Carte uniquement', 'getapay-woocommerce'))),
            'checkout_mode'=>array('title'=>__('Expérience de paiement', 'getapay-woocommerce'),'type'=>'select','default'=>'embedded','options'=>array('embedded'=>__('Intégrée au checkout (Mobile Money)', 'getapay-woocommerce')),'description'=>__('Le paiement Mobile Money est initié depuis le checkout. Les paiements par carte utilisent toujours la page sécurisée GetaPay.','getapay-woocommerce')),
            'exchange_rate'=>array('title'=>__('Taux manuel vers USD', 'getapay-woocommerce'),'type'=>'number','default'=>'','description'=>__('Nombre d’unités de la devise boutique pour 1 USD. Utilisé uniquement pour calculer les paiements carte lorsque la boutique est en devise locale.', 'getapay-woocommerce'),'custom_attributes'=>array('step'=>'0.000001','min'=>'0')),
            'test_connection'=>array('title'=>__('Connexion API', 'getapay-woocommerce'),'type'=>'getapay_connection','description'=>__('Enregistre les clés puis utilise le bouton de test pour vérifier la connexion.', 'getapay-woocommerce')),
        );
    }

    public function generate_getapay_connection_html() {
        return '<tr valign="top"><th scope="row">'.esc_html__('Tester la connexion','getapay-woocommerce').'</th><td><button type="button" class="button" id="getapay-test-connection">'.esc_html__('Tester la connexion','getapay-woocommerce').'</button><span id="getapay-test-result" style="margin-left:10px"></span><p class="description">'.esc_html__('Le test vérifie uniquement l’accès à l’API (solde). Il ne réalise aucun paiement.','getapay-woocommerce').'</p></td></tr>';
    }

    public function admin_options() {
        parent::admin_options();
        echo '<p><strong>'.esc_html__('URL du webhook à configurer dans GetaPay :','getapay-woocommerce').'</strong> <code>'.esc_html(add_query_arg('wc-api','getapay_webhook',home_url('/'))).'</code></p>';
        echo '<script>jQuery(function($){$("#getapay-test-connection").on("click",function(){var b=$(this),o=$("#getapay-test-result");b.prop("disabled",true);o.text("…");$.post(ajaxurl,{action:"getapay_test_connection",nonce:"'.esc_js(wp_create_nonce('getapay_test_connection')).'"}).done(function(r){o.text(r.success?r.data.message:r.data.message).css("color",r.success?"green":"#b32d2e");}).fail(function(){o.text("Erreur réseau").css("color","#b32d2e");}).always(function(){b.prop("disabled",false);});});});</script>';
    }

    public function payment_fields() {
        if ($this->description) echo wpautop(wp_kses_post($this->description));
        $methods = $this->get_option('methods','both');
        if ($methods === 'both') {
            echo '<p class="form-row form-row-wide"><label>'.esc_html__('Moyen de paiement','getapay-woocommerce').'</label><select name="getapay_method" id="getapay_method"><option value="mobile">Mobile Money</option><option value="card">Carte bancaire</option></select></p>';
        } else {
            echo '<input type="hidden" name="getapay_method" value="'.esc_attr($methods).'">';
        }
        if ($methods !== 'card') {
            echo '<div id="getapay-mobile-fields"><p class="form-row form-row-wide"><label for="getapay_country">'.esc_html__('Pays','getapay-woocommerce').'</label><select name="getapay_country" id="getapay_country"><option value="">'.esc_html__('Choisir un pays','getapay-woocommerce').'</option>';
            foreach ($this->getapay_countries as $code=>$country) echo '<option value="'.esc_attr($code).'" data-currency="'.esc_attr($country['currency']).'">'.esc_html($country['name'].' ('.$country['currency'].')').'</option>';
            echo '</select></p><p class="form-row form-row-wide"><label for="getapay_provider">'.esc_html__('Opérateur','getapay-woocommerce').'</label><select name="getapay_provider" id="getapay_provider"><option value="">'.esc_html__('Choisir un opérateur','getapay-woocommerce').'</option></select></p><p class="form-row form-row-wide"><label for="getapay_phone">'.esc_html__('Numéro Mobile Money','getapay-woocommerce').'</label><input type="tel" name="getapay_phone" id="getapay_phone" autocomplete="tel" placeholder="'.esc_attr__('Numéro du client','getapay-woocommerce').'" /></p><small class="getapay-hint">'.esc_html__('Le client devra confirmer la demande sur son téléphone.','getapay-woocommerce').'</small></div>';
        }
        if ($methods !== 'mobile') echo '<div id="getapay-card-fields" style="display:none"><p>'.esc_html__('Vous serez redirigé vers la page sécurisée GetaPay 3D Secure.','getapay-woocommerce').'</p></div>';
        echo '<div id="getapay-checkout-error" role="alert" aria-live="polite"></div>';
    }

    public function enqueue_assets() {
        $on_checkout = function_exists('is_checkout') && is_checkout() && !(function_exists('is_order_received_page') && is_order_received_page());
        $on_received = function_exists('is_order_received_page') && is_order_received_page();
        if (!$on_checkout && !$on_received) return;
        if ($on_received) {
            $order_id = absint(get_query_var('order-received'));
            $order = $order_id ? wc_get_order($order_id) : false;
            if (!$order || $order->get_payment_method() !== $this->id) return;
        }
        wp_enqueue_style('getapay-checkout', GETAPAY_WC_URL.'assets/checkout.css', array(), GETAPAY_WC_VERSION);
        wp_enqueue_script('getapay-checkout', GETAPAY_WC_URL.'assets/checkout.js', array('jquery'), GETAPAY_WC_VERSION, true);
        wp_localize_script('getapay-checkout','GetaPayCheckout',array('countries'=>$this->getapay_countries,'methods'=>$this->get_option('methods','both'),'mode'=>$this->get_option('checkout_mode','embedded'),'currency'=>get_woocommerce_currency(),'statusUrl'=>rest_url('getapay/v1/status/'),'i18n'=>array('choose'=>__('Choisir un opérateur','getapay-woocommerce'),'countryCurrency'=>__('La devise de la commande doit correspondre à la devise Mobile Money du pays sélectionné.','getapay-woocommerce'))));
    }

    public function validate_checkout() {
        if (empty($_POST['payment_method']) || sanitize_text_field(wp_unslash($_POST['payment_method'])) !== $this->id) return;
        $method = isset($_POST['getapay_method']) ? sanitize_key(wp_unslash($_POST['getapay_method'])) : '';
        $allowed = $this->get_option('methods','both');
        if (!in_array($method,array('mobile','card'),true) || ($allowed !== 'both' && $allowed !== $method)) wc_add_notice(__('Moyen de paiement non autorisé.','getapay-woocommerce'),'error');
        if ($method === 'mobile') {
            $country = isset($_POST['getapay_country']) ? sanitize_key(wp_unslash($_POST['getapay_country'])) : '';
            $provider = isset($_POST['getapay_provider']) ? strtoupper(sanitize_text_field(wp_unslash($_POST['getapay_provider']))) : '';
            $phone = isset($_POST['getapay_phone']) ? preg_replace('/[^0-9+]/','',wp_unslash($_POST['getapay_phone'])) : '';
            if (!isset($this->getapay_countries[$country]) || !in_array($provider,$this->getapay_countries[$country]['providers'],true)) wc_add_notice(__('Sélectionnez un pays et un opérateur valides.','getapay-woocommerce'),'error');
            if (strlen(preg_replace('/\D/','',$phone)) < 7 || strlen(preg_replace('/\D/','',$phone)) > 15) wc_add_notice(__('Saisissez un numéro de téléphone valide.','getapay-woocommerce'),'error');
            if (isset($this->getapay_countries[$country]) && get_woocommerce_currency() !== $this->getapay_countries[$country]['currency']) wc_add_notice(sprintf(__('La devise de cette commande (%1$s) ne correspond pas à la devise Mobile Money (%2$s).','getapay-woocommerce'),get_woocommerce_currency(),$this->getapay_countries[$country]['currency']),'error');
        }
        if ($method === 'card' && get_woocommerce_currency() !== 'USD' && (float)$this->get_option('exchange_rate') <= 0) wc_add_notice(__('Configurez un taux de conversion manuel vers USD pour accepter les cartes avec la devise actuelle de la boutique.','getapay-woocommerce'),'error');
    }

    public function process_payment($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) return array('result'=>'failure');
        $method = isset($_POST['getapay_method']) ? sanitize_key(wp_unslash($_POST['getapay_method'])) : 'mobile';
        $allowed = $this->get_option('methods', 'both');
        if (!in_array($method, array('mobile', 'card'), true) || ($allowed !== 'both' && $allowed !== $method)) return $this->payment_error($order, __('Moyen de paiement non autorisé.', 'getapay-woocommerce'));
        $reference = 'WC-' . $order->get_id() . '-' . wp_generate_password(8,false,false);
        $order->update_meta_data('_getapay_reference',$reference);
        $order->update_meta_data('_getapay_method',$method);
        $order->save();
        $return_url = add_query_arg(array('getapay_return'=>'1','order_id'=>$order->get_id(),'key'=>$order->get_order_key()),$this->get_return_url($order));
        if ($method === 'card') {
            $currency = get_woocommerce_currency();
            $amount = (float)$order->get_total();
            if ($currency !== 'USD') {
                $rate = (float)$this->get_option('exchange_rate');
                if ($rate <= 0) return $this->payment_error($order,__('Taux de conversion USD manquant.','getapay-woocommerce'));
                $amount = $amount / $rate; $currency = 'USD';
            }
            $payload = array('amount'=>round($amount,2),'currency'=>$currency,'card_provider'=>'VISA','customer_name'=>$order->get_formatted_billing_full_name(),'customer_email'=>$order->get_billing_email(),'customer_phone'=>$order->get_billing_phone(),'customer_address'=>$order->get_billing_address_1(),'customer_city'=>$order->get_billing_city(),'reference'=>$reference,'return_url'=>$return_url);
            $result = $this->api->request('POST','charges/card',$payload);
            if (is_wp_error($result)) return $this->payment_error($order,$result->get_error_message());
            $url = isset($result['payment_url']) ? esc_url_raw($result['payment_url']) : (isset($result['paymenturl']) ? esc_url_raw($result['paymenturl']) : '');
            if (!$url || !wp_http_validate_url($url) || strpos($url,'https://') !== 0) return $this->payment_error($order,__('GetaPay n’a pas retourné une URL de paiement sécurisée.','getapay-woocommerce'));
            $order->update_meta_data('_getapay_api_amount',round($amount,2)); $order->update_meta_data('_getapay_api_currency',$currency); $order->save();
            $order->update_status('pending',__('Paiement GetaPay créé ; confirmation 3D Secure en attente.','getapay-woocommerce'));
            return array('result'=>'success','redirect'=>$url);
        }
        $country = isset($_POST['getapay_country']) ? sanitize_key(wp_unslash($_POST['getapay_country'])) : '';
        $provider = isset($_POST['getapay_provider']) ? strtoupper(sanitize_text_field(wp_unslash($_POST['getapay_provider']))) : '';
        $phone = isset($_POST['getapay_phone']) ? preg_replace('/[^0-9+]/','',wp_unslash($_POST['getapay_phone'])) : '';
        $digits = preg_replace('/\D/', '', $phone);
        if (!isset($this->getapay_countries[$country]) || !in_array($provider, $this->getapay_countries[$country]['providers'], true) || strlen($digits) < 7 || strlen($digits) > 15 || get_woocommerce_currency() !== $this->getapay_countries[$country]['currency']) return $this->payment_error($order, __('Les informations Mobile Money ou la devise de la commande sont invalides.', 'getapay-woocommerce'));
        $payload = array('amount'=>(float)$order->get_total(),'currency'=>$this->getapay_countries[$country]['currency'],'country'=>$country,'provider'=>$provider,'phone_number'=>$phone,'reference'=>$reference,'customer_name'=>$order->get_formatted_billing_full_name(),'customer_email'=>$order->get_billing_email(),'customer_message'=>substr(sprintf(__('Commande #%s','getapay-woocommerce'),$order->get_order_number()),0,22),'metadata'=>array('order_id'=>(string)$order->get_id(),'order_key'=>$order->get_order_key()));
        $result = $this->api->request('POST','charges/mobile-money',$payload);
        if (is_wp_error($result)) return $this->payment_error($order,$result->get_error_message());
        if (empty($result['reference'])) return $this->payment_error($order,__('Réponse GetaPay incomplète : référence absente.','getapay-woocommerce'));
        $order->update_meta_data('_getapay_api_amount',(float)$payload['amount']); $order->update_meta_data('_getapay_api_currency',$payload['currency']); $order->update_meta_data('_getapay_transaction_id',isset($result['id'])?sanitize_text_field($result['id']):'');
        $order->update_status('on-hold',__('Demande Mobile Money envoyée. En attente de confirmation du client.','getapay-woocommerce'));
        $order->save();
        return array('result'=>'success','redirect'=>$this->get_return_url($order));
    }

    private function payment_error($order,$message) { wc_add_notice(wp_kses_post($message),'error'); return array('result'=>'failure'); }

    public function receipt_page($order_id) {
        $order = wc_get_order($order_id); if (!$order) return;
        echo '<div class="getapay-status" data-order="'.esc_attr($order->get_id()).'" data-key="'.esc_attr($order->get_order_key()).'"><strong>'.esc_html__('Vérification du paiement…','getapay-woocommerce').'</strong><p>'.esc_html__('Veuillez confirmer la demande sur votre téléphone si vous avez choisi Mobile Money.','getapay-woocommerce').'</p><span class="getapay-status-message" aria-live="polite"></span></div>';
    }

    public function register_rest_routes() {
        register_rest_route('getapay/v1','/status/(?P<order_id>\d+)',array('methods'=>'GET','callback'=>array($this,'rest_status'),'permission_callback'=>'__return_true'));
    }
    public function rest_status($request) {
        $order = wc_get_order(absint($request['order_id']));
        if (!$order || !hash_equals($order->get_order_key(),(string)$request->get_param('key')) || $order->get_payment_method() !== $this->id) return new WP_Error('forbidden','Not allowed',array('status'=>403));
        if (!$order->is_paid() && $order->get_meta('_getapay_reference')) {
            $check = $this->api->request('GET','charges/'.rawurlencode($order->get_meta('_getapay_reference')));
            if (!is_wp_error($check) && $this->verified_charge_matches_order($order, $check)) $this->apply_payment_status($order, $check);
        }
        return rest_ensure_response(array('status'=>$order->get_status(),'paid'=>$order->is_paid(),'message'=>$order->is_paid()?__('Paiement confirmé.','getapay-woocommerce'):__('Paiement en attente de confirmation.','getapay-woocommerce')));
    }

    public function handle_webhook() {
        $raw = file_get_contents('php://input');
        $timestamp = isset($_SERVER['HTTP_X_GETAPAY_TIMESTAMP']) ? (string)$_SERVER['HTTP_X_GETAPAY_TIMESTAMP'] : '';
        $signature = isset($_SERVER['HTTP_X_GETAPAY_SIGNATURE']) ? (string)$_SERVER['HTTP_X_GETAPAY_SIGNATURE'] : '';
        $secret = (string)$this->get_option('webhook_secret');
        if (!$secret || !ctype_digit($timestamp) || abs(time()-(int)$timestamp)>300 || !$signature) { status_header(401); exit; }
        $expected = hash_hmac('sha256',$timestamp.'.'.$raw,$secret);
        if (!hash_equals($expected,$signature)) { status_header(401); exit; }
        $event = json_decode($raw,true);
        if (!is_array($event) || empty($event['reference'])) { status_header(400); exit; }
        $order_id = 0;
        if (preg_match('/^WC-(\d+)-/',$event['reference'],$m)) $order_id = absint($m[1]);
        $order = $order_id ? wc_get_order($order_id) : false;
        if (!$order || $order->get_payment_method() !== $this->id || !hash_equals((string)$order->get_meta('_getapay_reference'),(string)$event['reference'])) { status_header(404); exit; }
        // A signed webhook is a notification, not the final payment authority.
        // Re-fetch the charge and reconcile it before changing the WooCommerce order.
        $charge = $this->api->request('GET', 'charges/' . rawurlencode($event['reference']));
        if (is_wp_error($charge) || !$this->verified_charge_matches_order($order, $charge)) { status_header(422); exit; }
        $this->apply_payment_status($order, $charge);
        status_header(200); echo 'OK'; exit;
    }

    private function verified_charge_matches_order($order, $data) {
        if (!is_array($data)) return false;
        $reference = isset($data['reference']) ? (string)$data['reference'] : '';
        $amount = isset($data['amount']) ? (float)$data['amount'] : null;
        $currency = isset($data['currency']) ? strtoupper((string)$data['currency']) : '';
        $expected_amount = (float)$order->get_meta('_getapay_api_amount');
        $expected_currency = strtoupper((string)$order->get_meta('_getapay_api_currency'));
        return $reference !== '' && hash_equals((string)$order->get_meta('_getapay_reference'), $reference)
            && $amount !== null && abs($amount - $expected_amount) < 0.00001
            && $currency !== '' && hash_equals($expected_currency, $currency);
    }

    private function apply_payment_status($order,$data) {
        $status = GetaPay_API::status($data);
        if ($status === 'completed' && !$order->is_paid()) {
            $order->payment_complete(isset($data['id'])?sanitize_text_field($data['id']):$order->get_meta('_getapay_transaction_id'));
            $order->add_order_note(__('Paiement confirmé par GetaPay.','getapay-woocommerce'));
        } elseif (in_array($status,array('failed','cancelled'),true) && !$order->is_paid()) {
            $order->update_status('failed',__('Paiement GetaPay échoué ou annulé.','getapay-woocommerce'));
        } elseif ($status === 'processing' && $order->has_status(array('pending','on-hold'))) {
            $order->update_status('on-hold',__('Paiement GetaPay en cours de traitement.','getapay-woocommerce'));
        }
    }

    public function limit_available_gateway($gateways) {
        if (isset($gateways[$this->id]) && !$this->get_option('secret_key')) unset($gateways[$this->id]);
        return $gateways;
    }
}

add_action('wp_ajax_getapay_test_connection',function(){
    if (!current_user_can('manage_woocommerce') || !check_ajax_referer('getapay_test_connection','nonce',false)) wp_send_json_error(array('message'=>__('Action non autorisée.','getapay-woocommerce')),403);
    $settings = get_option('woocommerce_getapay_settings',array());
    $api = new GetaPay_API(isset($settings['secret_key'])?$settings['secret_key']:'');
    $result = $api->request('GET','balance');
    if (is_wp_error($result)) wp_send_json_error(array('message'=>$result->get_error_message()));
    wp_send_json_success(array('message'=>__('Connexion API réussie.','getapay-woocommerce')));
});

add_action('woocommerce_thankyou_getapay',function($order_id){
    $order = wc_get_order($order_id); if (!$order) return;
    echo '<section class="getapay-status" data-order="'.esc_attr($order->get_id()).'" data-key="'.esc_attr($order->get_order_key()).'"><h3>'.esc_html__('Confirmation du paiement GetaPay','getapay-woocommerce').'</h3><p class="getapay-status-message" aria-live="polite">'.esc_html__('Vérification du statut du paiement…','getapay-woocommerce').'</p></section>';
});
