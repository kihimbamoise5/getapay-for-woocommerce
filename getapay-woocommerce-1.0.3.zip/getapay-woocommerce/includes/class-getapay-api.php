<?php
if (!defined('ABSPATH')) { exit; }

final class GetaPay_API {
    const BASE_URL = 'https://api.getapay.cash/api/v1';
    private $secret;
    public function __construct($secret) { $this->secret = trim((string) $secret); }

    public function request($method, $path, $body = null) {
        if (!$this->secret) return new WP_Error('getapay_missing_key', __('GetaPay secret key is missing.', 'getapay-woocommerce'));
        $args = array(
            'method' => strtoupper($method), 'timeout' => 25, 'redirection' => 0,
            'headers' => array('Authorization' => 'Bearer ' . $this->secret, 'Accept' => 'application/json', 'Content-Type' => 'application/json'),
        );
        if ($body !== null) $args['body'] = wp_json_encode($body);
        $response = wp_remote_request(self::BASE_URL . '/' . ltrim($path, '/'), $args);
        if (is_wp_error($response)) return $response;
        $code = (int) wp_remote_retrieve_response_code($response);
        $raw = wp_remote_retrieve_body($response);
        $data = json_decode($raw, true);
        if (!is_array($data)) return new WP_Error('getapay_bad_response', __('Invalid response received from GetaPay.', 'getapay-woocommerce'));
        if ($code < 200 || $code >= 300) {
            $message = isset($data['error']['message']) ? sanitize_text_field($data['error']['message']) : sprintf(__('GetaPay returned HTTP %d.', 'getapay-woocommerce'), $code);
            return new WP_Error('getapay_api_error', $message, array('status' => $code, 'response' => $data));
        }
        return $data;
    }

    public static function status($data) {
        $status = isset($data['status']) ? strtolower((string) $data['status']) : '';
        return in_array($status, array('pending','processing','completed','failed','cancelled'), true) ? $status : 'unknown';
    }
}
