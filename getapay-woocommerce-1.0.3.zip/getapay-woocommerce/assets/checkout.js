(function ($) {
  'use strict';
  function refreshProviders() {
    var countryCode = $('#getapay_country').val();
    var select = $('#getapay_provider');
    if (!select.length) return;
    select.empty().append($('<option>', { value: '', text: GetaPayCheckout.i18n.choose }));
    var country = GetaPayCheckout.countries[countryCode];
    if (!country) return;
    country.providers.forEach(function (provider) {
      select.append($('<option>', { value: provider, text: provider.replace(/_/g, ' ') }));
    });
  }
  function toggleMethod() {
    var method = $('input[name="getapay_method"]:checked').val() || $('#getapay_method').val() || $('input[name="getapay_method"]').val();
    $('#getapay-mobile-fields').toggle(method !== 'card');
    $('#getapay-card-fields').toggle(method === 'card');
  }
  $(document.body).on('change', '#getapay_country', refreshProviders);
  $(document.body).on('change', '#getapay_method', toggleMethod);
  $(document.body).on('updated_checkout', function () { refreshProviders(); toggleMethod(); });
  $(function () { refreshProviders(); toggleMethod(); });

  function pollStatus() {
    $('.getapay-status[data-order]').each(function () {
      var box = $(this), order = box.data('order'), key = box.data('key'), message = box.find('.getapay-status-message'), tries = 0;
      if (box.data('polling')) return;
      box.data('polling', true);
      function tick() {
        if (tries++ >= 24) { message.text('Le paiement est toujours en attente. Actualisez cette page dans quelques instants.'); return; }
        $.get(GetaPayCheckout.statusUrl + encodeURIComponent(order), { key: key }).done(function (r) {
          message.text(r.message || 'Statut mis à jour.');
          if (r.paid) { message.addClass('is-success'); return; }
          if (r.status === 'failed' || r.status === 'cancelled' || r.status === 'refunded') { message.addClass('is-error'); return; }
          window.setTimeout(tick, 5000);
        }).fail(function () { message.text('Impossible de vérifier le statut pour le moment.'); window.setTimeout(tick, 8000); });
      }
      tick();
    });
  }
  $(pollStatus);
})(jQuery);
