<?php
/**
 * Plugin Name: GetaPay for WooCommerce
 * Description: Accept Mobile Money and card payments through GetaPay.
 * Version: 1.0.3
 * Plugin URI: https://getapay.cash
 * Requires Plugins: woocommerce
 * Requires PHP: 7.4
 * Author: GetaPay
 * Author URI: https://getapay.cash
 * Text Domain: getapay-woocommerce
 */
if (!defined('ABSPATH')) { exit; }

define('GETAPAY_WC_VERSION', '1.0.3');
define('GETAPAY_WC_FILE', __FILE__);
define('GETAPAY_WC_PATH', plugin_dir_path(__FILE__));

define('GETAPAY_WC_URL', plugin_dir_url(__FILE__));

add_filter('plugin_action_links_' . plugin_basename(__FILE__), function ($links) {
    $settings_url = admin_url('admin.php?page=wc-settings&tab=checkout&section=getapay');
    array_unshift($links, '<a href="' . esc_url($settings_url) . '">' . esc_html__('Réglages', 'getapay-woocommerce') . '</a>');
    $links[] = '<a href="https://doc.getapay.cash" target="_blank" rel="noopener noreferrer">' . esc_html__('Documentation', 'getapay-woocommerce') . '</a>';
    $links[] = '<a href="https://getapay.cash" target="_blank" rel="noopener noreferrer">' . esc_html__('Site officiel', 'getapay-woocommerce') . '</a>';
    return $links;
});

add_action('plugins_loaded', function () {
    if (!class_exists('WooCommerce')) {
        add_action('admin_notices', function () {
            echo '<div class="notice notice-error"><p>' . esc_html__('GetaPay for WooCommerce requires WooCommerce to be installed and active.', 'getapay-woocommerce') . '</p></div>';
        });
        return;
    }
    require_once GETAPAY_WC_PATH . 'includes/class-getapay-api.php';
    require_once GETAPAY_WC_PATH . 'includes/class-getapay-gateway.php';
    add_filter('woocommerce_payment_gateways', function ($gateways) {
        $gateways[] = 'WC_Gateway_GetaPay';
        return $gateways;
    });
}, 20);

add_action('before_woocommerce_init', function () {
    if (class_exists(\Automattic\WooCommerce\Utilities\FeaturesUtil::class)) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
    }
});
