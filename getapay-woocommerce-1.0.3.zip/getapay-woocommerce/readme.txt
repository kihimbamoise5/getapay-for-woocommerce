=== GetaPay for WooCommerce ===
Contributors: getapay
Tags: woocommerce, payments, mobile money, getapay
Requires at least: 6.2
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0.3
License: GPLv2 or later

Accept Mobile Money and card payments through the GetaPay API.

== Configuration ==
1. Install and activate WooCommerce.
2. Upload and activate this plugin.
3. Open WooCommerce > Settings > Payments > GetaPay.
4. Enter the live secret API key and webhook signing secret.
5. Select the methods you wish to offer and save.
6. Copy the displayed webhook URL into GetaPay > API & Webhooks.
7. Use the connection test. It only reads the account balance and does not create a charge.

== Important limitations ==
- The API integration uses the documented `/charges/mobile-money`, `/charges/card`, `/charges/{reference}` and `/balance` endpoints.
- Mobile Money payments require the WooCommerce order currency to match the selected country's currency. No implicit FX conversion is performed.
- Card payments use USD directly. For another store currency, configure a manual rate expressed as store-currency units per 1 USD; the plugin converts the order total to USD before creating the card charge.
- The card network field currently defaults to VISA because the documented API does not expose a card-brand selection step before hosted checkout.
- Mobile Money is initiated from the WooCommerce checkout and its status is checked on the order confirmation page. Card checkout always redirects to the hosted 3-D Secure URL. A separate hosted Mobile Money flow is not exposed because its API contract has not been confirmed.
- No sandbox is documented. Do not test with real customer orders without a controlled low-value test and approval.
- Extension registration/activation with GetaPay is not implemented: no registration endpoint or request/response contract has been supplied. The plugin does not invent one or claim remote activation.
- Refunds and payouts are not mapped to WooCommerce refunds because a payout is not necessarily a refund and no refund API contract has been supplied.

== Security ==
Webhook requests are checked with HMAC-SHA256 over `timestamp + "." + raw request body` and a 5-minute timestamp window. The webhook is treated as a notification: the plugin re-fetches the charge from the API and requires an exact reference, amount, and currency match before updating the order. Customer-facing status checks require the WooCommerce order key. The API secret is only used server-side.


Version 1.0.3
- Corrected a fatal PHP property collision with WooCommerce's base payment gateway class.
- Added direct Settings, Documentation and Official website links on the Plugins page.
- Loaded checkout assets on the GetaPay order-received page so payment status polling can run.
